
# Stochastic Programs

Modify `plasma.py` so as to get the highest `pylint` score you can while still passing the tests in this notebook. 

Docstrings should be meaningful descriptions of the module, classes, methods, and functions. 


```python
%matplotlib inline
```


```python
from nose.tools import assert_equal, assert_true, assert_false, assert_raises, assert_almost_equal
```


```python
from plasma import *
```


```python
def simulation1():
    f = Plasma()
    f.populate(200, 70, 70)
    start_types = set([type(p) for p in f._particles])
    viewField(f, 800, 800)
    for k, v in count(f._particles, types=start_types).items():
            print("%s: %s"%(str(k).ljust(30),str(v).rjust(3)))
    print(KineticEnergy(f._particles))
    
    for i in range(3):
        f.run(1000)

        viewField(f, 800, 800)
        plt.show()
        print(f.collisions, f.decays, f.iterations)
        for k, v in count(f._particles, types=start_types).items():
            print("%s: %s"%(str(k).ljust(30),str(v).rjust(3)))
        print(KineticEnergy(f._particles))
        print("*"*42)
        print("\n")
    return f._particles
```


```python
random.seed(20181117)
particles = simulation1()
```

    <class 'plasma.Electron'>     :  36
    <class 'plasma.Positron'>     :   2
    <class 'plasma.Photon'>       :  39
    <class 'plasma.Atom'>         :  58
    <class 'plasma.Neutron'>      :  17
    <class 'plasma.Proton'>       :  48
    110748.0



![png](output_5_1.png)


    427 1 1000
    <class 'plasma.Electron'>     :  32
    <class 'plasma.Positron'>     :   2
    <class 'plasma.Photon'>       :  37
    <class 'plasma.Atom'>         :  61
    <class 'plasma.Neutron'>      :  18
    <class 'plasma.Proton'>       :  44
    111596.5
    ******************************************
    
    



![png](output_5_3.png)


    679 1 2000
    <class 'plasma.Electron'>     :  29
    <class 'plasma.Positron'>     :   2
    <class 'plasma.Photon'>       :  35
    <class 'plasma.Atom'>         :  64
    <class 'plasma.Neutron'>      :  18
    <class 'plasma.Proton'>       :  41
    112091.5
    ******************************************
    
    



![png](output_5_5.png)


    804 2 3000
    <class 'plasma.Electron'>     :  28
    <class 'plasma.Positron'>     :   3
    <class 'plasma.Photon'>       :  35
    <class 'plasma.Atom'>         :  65
    <class 'plasma.Neutron'>      :  19
    <class 'plasma.Proton'>       :  39
    112447.0
    ******************************************
    
    



```python
assert_true(isinstance(particles,list))
```


```python
assert_true(KineticEnergy(particles) > 0)
```


```python
neutron = Neutron
```


```python
f2 = Plasma()

neutrons = [neutron() for i in range(9)]

locations = [Location(i,j) for i in [-1,0,1] for j in [-1,0,1]]

for i in range(9):
    n = neutrons[i]
    n.location = locations[i]
    f2.addParticle(n)

f2.setup()

f2.iterateParticle(f2._particles[4])

assert_equal(f2.collisions,1)
```


```python
!pylint plasma.py
```

    ************* Module plasma
    plasma.py:24:4: C0103: Attribute name "x" doesn't conform to snake_case naming style (invalid-name)
    plasma.py:28:4: C0103: Attribute name "x2" doesn't conform to snake_case naming style (invalid-name)
    plasma.py:34:4: C0103: Attribute name "y" doesn't conform to snake_case naming style (invalid-name)
    plasma.py:38:4: C0103: Attribute name "y2" doesn't conform to snake_case naming style (invalid-name)
    plasma.py:56:0: R0205: Class 'Space' inherits from object, can be safely removed from bases in python3 (useless-object-inheritance)
    plasma.py:66:4: C0103: Method name "addParticle" doesn't conform to snake_case naming style (invalid-name)
    plasma.py:80:4: C0103: Method name "iterateParticle" doesn't conform to snake_case naming style (invalid-name)
    plasma.py:92:0: R0902: Too many instance attributes (9/7) (too-many-instance-attributes)
    plasma.py:114:4: R0912: Too many branches (13/12) (too-many-branches)
    plasma.py:164:4: W0221: Parameters differ from overridden 'place_particle' method (arguments-differ)
    plasma.py:170:4: W0221: Parameters differ from overridden 'addParticle' method (arguments-differ)
    plasma.py:191:16: E0602: Undefined variable 'view_field' (undefined-variable)
    plasma.py:244:8: W0105: String statement has no effect (pointless-string-statement)
    plasma.py:265:4: C0103: Attribute name "KineticEnergy" doesn't conform to snake_case naming style (invalid-name)
    plasma.py:353:0: C0103: Function name "viewField" doesn't conform to snake_case naming style (invalid-name)
    plasma.py:376:15: W0212: Access to a protected member _particles of a client class (protected-access)
    plasma.py:397:0: C0103: Function name "KineticEnergy" doesn't conform to snake_case naming style (invalid-name)
    
    ------------------------------------------------------------------
    Your code has been rated at 9.34/10 (previous run: 9.34/10, +0.00)
    

